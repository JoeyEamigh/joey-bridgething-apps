// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/host.js
var ExtensionError = class extends Error {
  kind;
  constructor(message, kind) {
    super(message);
    this.kind = kind;
    this.name = "ExtensionError";
  }
};
async function* readLines(reader) {
  const decoder = new TextDecoder();
  let buffered = "";
  try {
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done)
        break;
      buffered += decoder.decode(value, { stream: true });
      for (let cut = buffered.indexOf("\n"); cut >= 0; cut = buffered.indexOf("\n")) {
        const line = buffered.slice(0, cut);
        buffered = buffered.slice(cut + 1);
        if (line.trim().length > 0)
          yield line;
      }
    }
    buffered += decoder.decode();
    if (buffered.trim().length > 0)
      yield buffered;
  } finally {
    reader.releaseLock();
  }
}
var LineWriter = class {
  writer;
  encoder = new TextEncoder();
  tail = Promise.resolve();
  constructor(writable) {
    this.writer = writable.getWriter();
  }
  write(message) {
    const chunk = this.encoder.encode(`${JSON.stringify(message)}
`);
    const written = this.tail.then(() => this.writer.write(chunk));
    this.tail = written.catch(() => void 0);
    return written;
  }
  async close() {
    await this.tail;
    try {
      await this.writer.close();
    } catch {
      this.writer.releaseLock();
    }
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/deno.js
function denoHost() {
  const runtime = globalThis.Deno;
  if (!runtime) {
    throw new ExtensionError("extensions run under deno; no Deno global in this process", "no-runtime");
  }
  return {
    readable: runtime.stdin.readable,
    writable: runtime.stdout.writable,
    exit: (code) => runtime.exit(code)
  };
}

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/message.js
function json(data) {
  return { encoding: "json", data };
}
function asJson(message) {
  return message.encoding === "json" ? message.data : void 0;
}
var CHUNK = 32768;
function toBase64(bytes) {
  let latin1 = "";
  for (let i = 0; i < bytes.length; i += CHUNK) {
    latin1 += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  }
  return btoa(latin1);
}
function fromBase64(data) {
  const latin1 = atob(data);
  const bytes = new Uint8Array(latin1.length);
  for (let i = 0; i < latin1.length; i++)
    bytes[i] = latin1.charCodeAt(i);
  return bytes;
}
function intoWire(message) {
  if (typeof message === "string")
    return { encoding: "text", data: message };
  if (message instanceof Uint8Array)
    return { encoding: "binary", data: toBase64(message) };
  if (message.encoding === "binary")
    return { encoding: "binary", data: toBase64(message.data) };
  return message;
}
function fromWire(message) {
  if (message.encoding === "binary")
    return { encoding: "binary", data: fromBase64(message.data) };
  return message;
}

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/protocol.js
var EXTENSION_API_VERSION = 1;

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/runtime.js
function describe(value) {
  if (typeof value === "string")
    return value;
  if (value instanceof Error)
    return value.stack ?? `${value.name}: ${value.message}`;
  try {
    return JSON.stringify(value) ?? String(value);
  } catch {
    return String(value);
  }
}
var DeviceImpl = class {
  id;
  runtime;
  name = "";
  active = false;
  connected = false;
  config = {};
  constructor(id, runtime) {
    this.id = id;
    this.runtime = runtime;
  }
  send(message) {
    this.runtime.forward(this.id, message);
  }
};
var ExtensionRuntime = class {
  spec;
  host;
  writer;
  devices_ = /* @__PURE__ */ new Map();
  pending = /* @__PURE__ */ new Map();
  onDevice = /* @__PURE__ */ new Set();
  onMessage = /* @__PURE__ */ new Set();
  onConfig = /* @__PURE__ */ new Set();
  nextRequestId = 1;
  started = false;
  finishing;
  settled;
  helloApi = EXTENSION_API_VERSION;
  helloWebapp = { id: "", name: "", version: "" };
  helloDataDir = "";
  reader;
  constructor(spec, host) {
    this.spec = spec;
    this.host = host;
    this.writer = new LineWriter(host.writable);
  }
  get api() {
    return this.helloApi;
  }
  get webapp() {
    return this.helloWebapp;
  }
  get dataDir() {
    return this.helloDataDir;
  }
  get devices() {
    return [...this.devices_.values()].filter((device) => device.connected);
  }
  device(id) {
    return this.ensure(id);
  }
  broadcast(message) {
    this.forward(void 0, message);
  }
  config(device) {
    const id = typeof device === "string" ? device : device.id;
    return this.devices_.get(id)?.config ?? {};
  }
  on(event, listener) {
    if (event === "device") {
      const fn2 = listener;
      this.onDevice.add(fn2);
      return () => this.onDevice.delete(fn2);
    }
    if (event === "message") {
      const fn2 = listener;
      this.onMessage.add(fn2);
      return () => this.onMessage.delete(fn2);
    }
    const fn = listener;
    this.onConfig.add(fn);
    return () => this.onConfig.delete(fn);
  }
  kv = {
    get: (key) => this.request((id) => ({ t: "kv.get", id, key })).then((value) => value === null ? void 0 : value),
    set: (key, value) => this.request((id) => ({ t: "kv.set", id, key, value })).then(() => void 0),
    delete: (key) => this.request((id) => ({ t: "kv.delete", id, key })).then(() => void 0),
    list: () => this.request((id) => ({ t: "kv.list", id })).then((value) => value ?? [])
  };
  auth = {
    authorize: (url) => this.request((id) => ({ t: "auth.authorize", id, url })).then((value) => String(value))
  };
  log = {
    debug: (...args) => this.log.log("debug", ...args),
    info: (...args) => this.log.log("info", ...args),
    warn: (...args) => this.log.log("warn", ...args),
    error: (...args) => this.log.log("error", ...args),
    log: (level, ...args) => {
      this.emit({ t: "log", level, message: args.map(describe).join(" ") });
    }
  };
  forward(device, message) {
    const wire = intoWire(message);
    this.emit(device === void 0 ? { t: "device.send", message: wire } : { t: "device.send", device, message: wire });
  }
  async run() {
    this.reader = this.host.readable.getReader();
    try {
      for await (const line of readLines(this.reader)) {
        const message = this.parse(line);
        if (!message)
          continue;
        if (message.t === "stop") {
          await this.finish(0);
          return;
        }
        this.dispatch(message);
      }
    } catch (err) {
      await this.finish(1, new ExtensionError(`stdin read failed: ${describe(err)}`, "disconnected"));
      return;
    }
    await this.finish(0);
  }
  ensure(id) {
    const existing = this.devices_.get(id);
    if (existing)
      return existing;
    const fresh = new DeviceImpl(id, this);
    this.devices_.set(id, fresh);
    return fresh;
  }
  parse(line) {
    try {
      return JSON.parse(line);
    } catch (err) {
      this.log.error(`unparseable line from host: ${describe(err)}`);
      return void 0;
    }
  }
  dispatch(message) {
    switch (message.t) {
      case "hello": {
        this.helloApi = message.api;
        this.helloWebapp = message.webapp;
        this.helloDataDir = message.dataDir;
        this.begin();
        return;
      }
      case "device.connected": {
        const device = this.ensure(message.device);
        device.name = message.name;
        device.config = { ...message.config };
        device.active = message.active;
        device.connected = true;
        this.announce({ type: "connected", device });
        return;
      }
      case "device.disconnected": {
        const device = this.devices_.get(message.device);
        if (!device)
          return;
        device.connected = false;
        device.active = false;
        this.announce({ type: "disconnected", device });
        return;
      }
      case "device.active": {
        const device = this.ensure(message.device);
        device.active = message.active;
        this.announce({ type: "active", device });
        return;
      }
      case "device.message": {
        const device = this.ensure(message.device);
        const forwarded = this.guard(() => fromWire(message.message));
        if (!forwarded)
          return;
        for (const listener of [...this.onMessage])
          this.guard(() => listener(device, forwarded));
        return;
      }
      case "config.changed": {
        const device = this.ensure(message.device);
        const next = { ...device.config };
        if (message.value === null)
          delete next[message.key];
        else
          next[message.key] = message.value;
        device.config = next;
        for (const listener of [...this.onConfig]) {
          this.guard(() => listener(device, message.key, message.value));
        }
        return;
      }
      case "reply": {
        const waiting = this.pending.get(message.id);
        if (!waiting)
          return;
        this.pending.delete(message.id);
        if (message.ok)
          waiting.resolve(message.value);
        else
          waiting.reject(new ExtensionError(message.error, "host-error"));
        return;
      }
    }
  }
  begin() {
    if (this.started)
      return;
    this.started = true;
    let starting;
    try {
      starting = this.spec.start(this);
    } catch (err) {
      this.abortStart(err);
      return;
    }
    void Promise.resolve(starting).then(() => this.emit({ t: "ready" }), (err) => this.abortStart(err));
  }
  abortStart(err) {
    this.log.error(`start failed: ${describe(err)}`);
    void this.finish(1, new ExtensionError(describe(err), "host-error"));
  }
  announce(event) {
    for (const listener of [...this.onDevice])
      this.guard(() => listener(event));
  }
  guard(run) {
    try {
      return run();
    } catch (err) {
      this.log.error(describe(err));
      return void 0;
    }
  }
  emit(message) {
    this.writer.write(message).catch((err) => {
      void this.finish(1, new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
    });
  }
  request(build) {
    if (this.settled) {
      const advice = "kv and auth cannot be reached once shutdown has begun, so persist eagerly rather than from stop";
      return Promise.reject(new ExtensionError(`${this.settled.message}; ${advice}`, this.settled.kind));
    }
    const id = String(this.nextRequestId++);
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.writer.write(build(id)).catch((err) => {
        if (!this.pending.delete(id))
          return;
        reject(new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
      });
    });
  }
  finish(code, reason) {
    this.finishing ??= this.shutdown(code, reason);
    return this.finishing;
  }
  async shutdown(code, reason) {
    const failure = reason ?? new ExtensionError("the host closed the connection", "disconnected");
    this.settled = failure;
    await this.reader?.cancel().catch(() => void 0);
    for (const waiting of [...this.pending.values()])
      waiting.reject(failure);
    this.pending.clear();
    try {
      await this.spec.stop?.();
    } catch (err) {
      await this.writer.write({ t: "log", level: "error", message: `stop failed: ${describe(err)}` }).catch(() => void 0);
    }
    await this.writer.close();
    this.host.exit(code);
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/index.js
function defineExtension(spec, host = denoHost()) {
  return new ExtensionRuntime(spec, host).run();
}

// extension/accounts.ts
var DEFAULT_SERVICE = "Claude Code-credentials";
function home() {
  const dir = Deno.env.get("HOME") ?? Deno.env.get("USERPROFILE");
  if (!dir) throw new Error("no HOME in the environment");
  return dir.replace(/[/\\]+$/, "");
}
function defaultConfigDir() {
  return `${home()}/.claude`;
}
async function shortHash(value) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("").slice(0, 8);
}
async function keychainService(dir) {
  const path = dir.replace(/\/+$/, "");
  return path === defaultConfigDir() ? DEFAULT_SERVICE : `${DEFAULT_SERVICE}-${await shortHash(path)}`;
}
async function capture(bin, args) {
  try {
    const out = await new Deno.Command(bin, { args, stdout: "piped", stderr: "null" }).output();
    return out.success ? new TextDecoder().decode(out.stdout).trim() : null;
  } catch {
    return null;
  }
}
function parseCredential(raw) {
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return null;
  }
  const oauth = parsed.claudeAiOauth;
  if (!oauth?.accessToken || !oauth.refreshToken || typeof oauth.expiresAt !== "number") return null;
  return {
    accessToken: oauth.accessToken,
    refreshToken: oauth.refreshToken,
    expiresAt: oauth.expiresAt,
    refreshTokenExpiresAt: oauth.refreshTokenExpiresAt ?? null,
    scopes: oauth.scopes ?? [],
    subscriptionType: oauth.subscriptionType ?? null,
    rateLimitTier: oauth.rateLimitTier ?? null
  };
}
async function readCredential(dir) {
  if (Deno.build.os === "darwin") {
    const raw = await capture("security", ["find-generic-password", "-s", await keychainService(dir), "-w"]);
    return raw ? parseCredential(raw) : null;
  }
  try {
    return parseCredential(await Deno.readTextFile(`${dir}/.credentials.json`));
  } catch {
    return null;
  }
}
async function writeCredential(dir, credential) {
  const payload = JSON.stringify({ claudeAiOauth: credential });
  if (Deno.build.os === "darwin") {
    const service = await keychainService(dir);
    const result = await new Deno.Command("security", {
      args: ["add-generic-password", "-U", "-s", service, "-a", service, "-w", payload],
      stdout: "null",
      stderr: "piped"
    }).output();
    if (!result.success) throw new Error(new TextDecoder().decode(result.stderr).trim() || "keychain write failed");
    return;
  }
  const target = `${dir}/.credentials.json`;
  const scratch = `${target}.${crypto.randomUUID()}`;
  await Deno.writeTextFile(scratch, payload, { mode: 384 });
  await Deno.rename(scratch, target);
}
function isConfigDir(path) {
  for (const marker of [".claude.json", "projects"]) {
    try {
      Deno.statSync(`${path}/${marker}`);
      return true;
    } catch {
      continue;
    }
  }
  return false;
}
function displayName(dir) {
  const base = dir.slice(dir.lastIndexOf("/") + 1);
  return base === ".claude" ? "default" : base.replace(/^\.claude-?/, "") || base;
}
function discover() {
  const root = home();
  const fallback = defaultConfigDir();
  const found = [];
  try {
    for (const entry of Deno.readDirSync(root)) {
      if (!entry.name.startsWith(".claude")) continue;
      const path = `${root}/${entry.name}`;
      if (!entry.isDirectory && !entry.isSymlink) continue;
      if (!isConfigDir(path)) continue;
      found.push({ dir: path, name: displayName(path), isDefault: path === fallback });
    }
  } catch {
    if (isConfigDir(fallback)) found.push({ dir: fallback, name: "default", isDefault: true });
  }
  found.sort((a, b) => Number(b.isDefault) - Number(a.isDefault) || a.dir.localeCompare(b.dir));
  return found;
}
function configFilePaths(dir) {
  return dir === defaultConfigDir() ? [`${home()}/.claude.json`, `${dir}/.claude.json`] : [`${dir}/.claude.json`];
}
async function readLabel(dir) {
  for (const path of configFilePaths(dir)) {
    let parsed;
    try {
      parsed = JSON.parse(await Deno.readTextFile(path));
    } catch {
      continue;
    }
    const account = parsed.oauthAccount;
    if (!account?.emailAddress) continue;
    return {
      email: account.emailAddress,
      orgName: account.organizationName ?? null,
      subscriptionType: account.organizationType?.replace(/^claude_/, "") ?? null,
      tier: account.organizationRateLimitTier ?? null
    };
  }
  return null;
}
function projectsRoots(accounts) {
  const byReal = /* @__PURE__ */ new Map();
  for (const account of accounts) {
    let real;
    try {
      real = Deno.realPathSync(`${account.dir}/projects`);
    } catch {
      continue;
    }
    const owners = byReal.get(real) ?? [];
    owners.push(account.name);
    byReal.set(real, owners);
  }
  return byReal;
}

// extension/hookconfig.ts
var HOOK_PATH = "/bridgething-claude-usage";
function settingsPath(dir) {
  return `${dir}/settings.json`;
}
async function readSettings(path) {
  try {
    const parsed = JSON.parse(await Deno.readTextFile(path));
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}
async function writeSettings(path, settings) {
  const scratch = `${path}.${crypto.randomUUID()}`;
  await Deno.writeTextFile(scratch, `${JSON.stringify(settings, null, 2)}
`);
  await Deno.rename(scratch, path);
}
async function backupOnce(path) {
  const backup = `${path}.before-claude-usage`;
  try {
    await Deno.stat(backup);
    return;
  } catch {
  }
  try {
    await Deno.writeTextFile(backup, await Deno.readTextFile(path));
  } catch {
  }
}
function ours(hook) {
  return hook.type === "http" && typeof hook.url === "string" && hook.url.includes(HOOK_PATH);
}
function withoutOurs(matchers) {
  return matchers.map((entry) => ({ ...entry, hooks: (entry.hooks ?? []).filter((hook) => !ours(hook)) })).filter((entry) => (entry.hooks ?? []).length > 0);
}
function plan(settings, matcher, url, seconds) {
  const hooks = { ...settings.hooks ?? {} };
  const preToolUse = withoutOurs(hooks.PreToolUse ?? []);
  preToolUse.push({
    matcher,
    hooks: [{ type: "http", url, timeout: seconds, statusMessage: "Asking the Car Thing..." }]
  });
  hooks.PreToolUse = preToolUse;
  return { ...settings, hooks };
}
function unplan(settings) {
  const hooks = { ...settings.hooks ?? {} };
  const preToolUse = withoutOurs(hooks.PreToolUse ?? []);
  if (preToolUse.length > 0) hooks.PreToolUse = preToolUse;
  else delete hooks.PreToolUse;
  if (Object.keys(hooks).length === 0) {
    const rest = { ...settings };
    delete rest.hooks;
    return rest;
  }
  return { ...settings, hooks };
}
async function apply(dirs, rewrite, backup) {
  const result = { touched: [], failed: [] };
  for (const dir of dirs) {
    const path = settingsPath(dir);
    try {
      const settings = await readSettings(path);
      const next = rewrite(settings);
      if (JSON.stringify(next) === JSON.stringify(settings)) continue;
      if (backup) await backupOnce(path);
      await writeSettings(path, next);
      result.touched.push(path);
    } catch (err) {
      result.failed.push({ path, detail: err instanceof Error ? err.message : String(err) });
    }
  }
  return result;
}
function install(dirs, matcher, url, seconds) {
  return apply(dirs, (settings) => plan(settings, matcher, url, seconds), true);
}
function uninstall(dirs) {
  return apply(dirs, unplan, false);
}

// extension/prompts.ts
var PRESENCE_MS = 3 * 60 * 1e3;
var HOLDING_MODES = /* @__PURE__ */ new Set(["default", "plan"]);
function projectName(cwd) {
  const trimmed = cwd.replace(/\/+$/, "");
  return trimmed.slice(trimmed.lastIndexOf("/") + 1) || trimmed;
}
function oneLine(value, limit) {
  return String(value).replace(/\s+/g, " ").trim().slice(0, limit);
}
function describe2(tool, input) {
  const path = input.file_path ?? input.notebook_path ?? input.path;
  if (typeof input.command === "string") {
    return { summary: oneLine(input.command, 160), detail: oneLine(input.description ?? "", 120) || null };
  }
  if (typeof path === "string") return { summary: oneLine(path, 160), detail: null };
  if (typeof input.url === "string") return { summary: oneLine(input.url, 160), detail: null };
  if (typeof input.pattern === "string") return { summary: oneLine(input.pattern, 160), detail: null };
  const keys = Object.keys(input);
  return { summary: keys.length > 0 ? oneLine(JSON.stringify(input), 160) : tool, detail: null };
}
function decisionBody(decision) {
  return JSON.stringify({
    hookSpecificOutput: {
      hookEventName: "PreToolUse",
      permissionDecision: decision,
      permissionDecisionReason: decision === "allow" ? "Allowed from the Car Thing." : "Denied from the Car Thing."
    }
  });
}
var PASS = "{}";
var PromptServer = class {
  constructor(onChange, canHold, log) {
    this.onChange = onChange;
    this.canHold = canHold;
    this.log = log;
  }
  onChange;
  canHold;
  log;
  server;
  pending = /* @__PURE__ */ new Map();
  presentAt = 0;
  holdMs = 25e3;
  listening = false;
  error = null;
  url(port) {
    return `http://127.0.0.1:${port}${HOOK_PATH}`;
  }
  markPresent() {
    this.presentAt = Date.now();
  }
  get holding() {
    return this.pending.size > 0;
  }
  queue() {
    return [...this.pending.values()].map((entry) => entry.view).sort((a, b) => a.askedAt - b.askedAt);
  }
  answer(id, decision) {
    this.pending.get(id)?.settle(decision);
  }
  start(port, holdSeconds) {
    this.holdMs = Math.max(5, holdSeconds) * 1e3;
    if (this.server) return;
    this.error = null;
    try {
      this.server = Deno.serve(
        { port, hostname: "127.0.0.1", onListen: () => void 0 },
        (request) => this.handle(request)
      );
      this.listening = true;
    } catch (err) {
      this.listening = false;
      this.error = err instanceof Error ? err.message : String(err);
    }
    this.onChange();
  }
  async stop() {
    for (const entry of [...this.pending.values()]) entry.settle(null);
    this.listening = false;
    const server = this.server;
    this.server = void 0;
    await server?.shutdown().catch(() => {
    });
    this.onChange();
  }
  async handle(request) {
    if (new URL(request.url).pathname !== HOOK_PATH) return new Response("not found", { status: 404 });
    let payload;
    try {
      payload = await request.json();
    } catch {
      return json2(PASS);
    }
    const mode = payload.permission_mode ?? "default";
    const skip = !HOLDING_MODES.has(mode) ? `permission mode ${mode}` : Date.now() - this.presentAt >= PRESENCE_MS ? "nobody at the device" : !this.canHold() ? "no car thing showing this app" : null;
    if (skip) {
      this.log(`passed ${payload.tool_name ?? "tool"} through: ${skip}`);
      return json2(PASS);
    }
    const cwd = payload.cwd ?? "";
    const tool = payload.tool_name ?? "tool";
    const { summary, detail } = describe2(tool, payload.tool_input ?? {});
    const askedAt = Date.now();
    const id = payload.tool_use_id ?? crypto.randomUUID();
    const view2 = {
      id,
      tool,
      summary,
      detail,
      project: cwd ? projectName(cwd) : "unknown",
      session: (payload.session_id ?? "").slice(0, 8),
      mode,
      askedAt,
      expiresAt: askedAt + this.holdMs
    };
    const decision = await new Promise((resolve) => {
      let done = false;
      const settle = (value) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        this.pending.delete(id);
        this.onChange();
        resolve(value);
      };
      const timer = setTimeout(() => settle(null), this.holdMs);
      this.pending.set(id, { view: view2, settle });
      this.onChange();
    });
    return json2(decision ? decisionBody(decision) : PASS);
  }
};
function json2(body) {
  return new Response(body, { status: 200, headers: { "content-type": "application/json" } });
}

// extension/refresh.ts
var TOKEN_URL = "https://platform.claude.com/v1/oauth/token";
var CLIENT_ID = "9d1c250a-e61b-44d9-88ed-5944d1962f5e";
var MARGIN_MS = 6e4;
var LOCK_STALE_MS = 3e4;
function needsRefresh(credential, now = Date.now()) {
  return credential.expiresAt - now <= MARGIN_MS;
}
function refreshTokenUsable(credential, now = Date.now()) {
  return credential.refreshTokenExpiresAt === null || credential.refreshTokenExpiresAt > now;
}
async function lockName(dir) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(dir));
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("").slice(0, 12);
}
async function acquire(path) {
  try {
    const file = await Deno.open(path, { createNew: true, write: true });
    file.close();
    return true;
  } catch {
    try {
      const info = await Deno.stat(path);
      const age = Date.now() - (info.mtime?.getTime() ?? 0);
      if (age < LOCK_STALE_MS) return false;
      await Deno.remove(path);
    } catch {
      return false;
    }
    return acquire(path);
  }
}
async function release(path) {
  await Deno.remove(path).catch(() => {
  });
}
async function refreshCredential(dir, lockDir) {
  const lock = `${lockDir}/refresh-${await lockName(dir)}.lock`;
  if (!await acquire(lock)) return { kind: "busy" };
  try {
    const current = await readCredential(dir);
    if (!current) return { kind: "failed", detail: "no credential in the store" };
    if (!needsRefresh(current)) return { kind: "already-fresh", credential: current };
    if (!refreshTokenUsable(current)) return { kind: "failed", detail: "refresh token has expired" };
    let response;
    try {
      response = await fetch(TOKEN_URL, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          grant_type: "refresh_token",
          refresh_token: current.refreshToken,
          client_id: CLIENT_ID
        })
      });
    } catch (err) {
      return { kind: "failed", detail: err instanceof Error ? err.message : String(err) };
    }
    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      return { kind: "failed", detail: detail.slice(0, 200) || `http ${response.status}` };
    }
    const body = await response.json();
    if (!body.access_token || !body.refresh_token || typeof body.expires_in !== "number") {
      return { kind: "failed", detail: "token response was missing half the pair" };
    }
    const rotated = {
      ...current,
      accessToken: body.access_token,
      refreshToken: body.refresh_token,
      expiresAt: Date.now() + body.expires_in * 1e3
    };
    await writeCredential(dir, rotated);
    return { kind: "refreshed", credential: rotated };
  } finally {
    await release(lock);
  }
}

// extension/models.ts
var MODELS_URL = "https://api.anthropic.com/v1/models";
var OAUTH_BETA = "oauth-2025-04-20";
var API_VERSION = "2023-06-01";
var KV_MODELS = "models.limits";
var TTL_MS = 7 * 24 * 60 * 60 * 1e3;
var MISS_TTL_MS = 60 * 60 * 1e3;
var ModelLimits = class {
  constructor(kv, log) {
    this.kv = kv;
    this.log = log;
  }
  kv;
  log;
  cache = {};
  loaded = false;
  inflight = /* @__PURE__ */ new Set();
  async ready() {
    if (this.loaded) return;
    this.cache = await this.kv.get(KV_MODELS) ?? {};
    this.loaded = true;
  }
  limit(model) {
    if (!model) return null;
    return this.cache[model]?.limit ?? null;
  }
  async prime(models, accessToken) {
    await this.ready();
    const now = Date.now();
    const wanted = [...new Set(models)].filter((model) => {
      if (!model || model.startsWith("<") || this.inflight.has(model)) return false;
      const held = this.cache[model];
      if (!held) return true;
      return now - held.at > (held.limit === null ? MISS_TTL_MS : TTL_MS);
    });
    if (wanted.length === 0) return false;
    for (const model of wanted) this.inflight.add(model);
    try {
      const found = await Promise.all(wanted.map((model) => this.fetchOne(model, accessToken)));
      for (const [index, limit] of found.entries()) {
        this.cache[wanted[index]] = { limit, at: Date.now() };
      }
      await this.kv.set(KV_MODELS, this.cache).catch(() => {
      });
    } finally {
      for (const model of wanted) this.inflight.delete(model);
    }
    return true;
  }
  async fetchOne(model, accessToken) {
    try {
      const response = await fetch(`${MODELS_URL}/${encodeURIComponent(model)}`, {
        headers: {
          authorization: `Bearer ${accessToken}`,
          "anthropic-beta": OAUTH_BETA,
          "anthropic-version": API_VERSION
        }
      });
      if (!response.ok) {
        await response.body?.cancel();
        return null;
      }
      const body = await response.json();
      return typeof body.max_input_tokens === "number" ? body.max_input_tokens : null;
    } catch (err) {
      this.log(`could not read the context window for ${model}: ${err instanceof Error ? err.message : String(err)}`);
      return null;
    }
  }
};

// extension/transcripts.ts
var CHUNK2 = 1 << 20;
var DAYS_SHOWN = 21;
var TOP_PROJECTS = 6;
var SESSION_HORIZON_MS = 12 * 60 * 60 * 1e3;
var RUNNING_MS = 6e4;
var KV_FILES = "scan.files";
var KV_ROLLUP = "scan.rollup";
var KV_SCHEMA = "scan.schema";
var SCHEMA = 3;
var MAX_DEPTH = 4;
function contextFill(usage) {
  const last = usage.iterations?.at(-1) ?? usage;
  return (last.input_tokens ?? 0) + (last.cache_creation_input_tokens ?? 0) + (last.cache_read_input_tokens ?? 0);
}
function emptyRollup() {
  return { days: {}, models: {}, projects: {}, messages: 0, dayMessages: {} };
}
function add(into, key, quad) {
  const at = into[key] ??= [0, 0, 0, 0];
  at[0] += quad[0];
  at[1] += quad[1];
  at[2] += quad[2];
  at[3] += quad[3];
}
function toks(quad) {
  const [input, cacheWrite, cacheRead, output] = quad ?? [0, 0, 0, 0];
  return { input, cacheWrite, cacheRead, output };
}
function localDay(iso, fallback) {
  const at = iso ? Date.parse(iso) : NaN;
  const date = new Date(Number.isFinite(at) ? at : fallback);
  const month = `${date.getMonth() + 1}`.padStart(2, "0");
  const day = `${date.getDate()}`.padStart(2, "0");
  return `${date.getFullYear()}-${month}-${day}`;
}
function lastToolUseId(content) {
  if (!Array.isArray(content)) return null;
  for (let at = content.length - 1; at >= 0; at--) {
    const block = content[at];
    if (block?.type === "tool_use" && block.id) return block.id;
  }
  return null;
}
var DECODER = new TextDecoder();
var ENCODER = new TextEncoder();
var NEWLINE = 10;
function encode(value) {
  return ENCODER.encode(value);
}
var ASSISTANT = encode('"type":"assistant"');
var AI_TITLE = encode('"aiTitle"');
function includesBytes(haystack, needle) {
  const last = haystack.length - needle.length;
  const head = needle[0];
  outer: for (let at = 0; at <= last; at++) {
    if (haystack[at] !== head) continue;
    for (let index = 1; index < needle.length; index++) {
      if (haystack[at + index] !== needle[index]) continue outer;
    }
    return true;
  }
  return false;
}
function concat(left, right) {
  if (left.length === 0) return right.slice();
  const out = new Uint8Array(left.length + right.length);
  out.set(left);
  out.set(right, left.length);
  return out;
}
function projectName2(cwd) {
  const trimmed = cwd.replace(/\/+$/, "");
  return trimmed.slice(trimmed.lastIndexOf("/") + 1) || trimmed;
}
var TranscriptScanner = class {
  constructor(kv, log) {
    this.kv = kv;
    this.log = log;
  }
  kv;
  log;
  files = {};
  rollup = emptyRollup();
  loaded = false;
  done = 0;
  total = 0;
  running = false;
  async load() {
    if (this.loaded) return;
    const schema = await this.kv.get(KV_SCHEMA);
    if (schema === SCHEMA) {
      this.files = await this.kv.get(KV_FILES) ?? {};
      this.rollup = await this.kv.get(KV_ROLLUP) ?? emptyRollup();
    }
    this.loaded = true;
  }
  async persist() {
    await this.kv.set(KV_FILES, this.files);
    await this.kv.set(KV_ROLLUP, this.rollup);
    await this.kv.set(KV_SCHEMA, SCHEMA);
  }
  list(root) {
    const out = [];
    const walk = (dir, depth, sub) => {
      if (depth > MAX_DEPTH) return;
      let entries;
      try {
        entries = [...Deno.readDirSync(dir)];
      } catch {
        return;
      }
      for (const entry of entries) {
        const path = `${dir}/${entry.name}`;
        if (entry.isDirectory) walk(path, depth + 1, sub || entry.name === "subagents");
        else if (entry.isFile && entry.name.endsWith(".jsonl")) {
          try {
            const info = Deno.statSync(path);
            out.push({ path, size: info.size, mtime: info.mtime?.getTime() ?? 0, sub });
          } catch {
            continue;
          }
        }
      }
    };
    walk(root, 0, false);
    out.sort((a, b) => b.mtime - a.mtime);
    return out;
  }
  consume(state, line, mtime) {
    let record;
    try {
      record = JSON.parse(line);
    } catch {
      return;
    }
    state.sid ??= record.sessionId;
    state.cwd ??= record.cwd;
    const usage = record.message?.usage;
    if (usage) {
      const quad = [
        usage.input_tokens ?? 0,
        usage.cache_creation_input_tokens ?? 0,
        usage.cache_read_input_tokens ?? 0,
        usage.output_tokens ?? 0
      ];
      const day = localDay(record.timestamp, mtime);
      add(this.rollup.days, day, quad);
      this.rollup.dayMessages[day] = (this.rollup.dayMessages[day] ?? 0) + 1;
      this.rollup.messages += 1;
      if (record.message?.model && !record.message.model.startsWith("<")) {
        add(this.rollup.models, record.message.model, quad);
      }
      if (state.cwd) add(this.rollup.projects, state.cwd, quad);
    }
    if (record.timestamp) state.at = Date.parse(record.timestamp);
    if (record.isSidechain === true) return;
    state.br = record.gitBranch ?? null;
    if (record.message?.model) state.md = record.message.model;
    if (usage) state.cx = contextFill(usage);
    state.pt = lastToolUseId(record.message?.content);
  }
  title(state, line) {
    try {
      const record = JSON.parse(line);
      if (record.aiTitle) state.ti = record.aiTitle;
    } catch {
      return;
    }
  }
  line(state, bytes, mtime) {
    if (bytes.length === 0) return;
    if (includesBytes(bytes, ASSISTANT)) {
      this.consume(state, DECODER.decode(bytes), mtime);
      return;
    }
    if (state.pt && includesBytes(bytes, encode(state.pt))) {
      state.pt = null;
      return;
    }
    if (includesBytes(bytes, AI_TITLE)) this.title(state, DECODER.decode(bytes));
  }
  async scanFile({ path, size, mtime, sub }) {
    const state = this.files[path] ??= { o: 0, s: 0, m: 0 };
    if (sub) state.sb = true;
    if (size < state.o) state.o = 0;
    if (size === state.s && mtime === state.m) return;
    let file;
    try {
      file = await Deno.open(path, { read: true });
    } catch {
      return;
    }
    try {
      await file.seek(state.o, Deno.SeekMode.Start);
      const buffer = new Uint8Array(CHUNK2);
      let carry = new Uint8Array(0);
      let consumed = state.o;
      for (; ; ) {
        const read = await file.read(buffer);
        if (read === null) break;
        const chunk = buffer.subarray(0, read);
        const cut = chunk.lastIndexOf(NEWLINE);
        if (cut < 0) {
          carry = concat(carry, chunk);
          continue;
        }
        const complete = concat(carry, chunk.subarray(0, cut + 1));
        let at = 0;
        for (; ; ) {
          const next = complete.indexOf(NEWLINE, at);
          if (next < 0) break;
          this.line(state, complete.subarray(at, next), mtime);
          at = next + 1;
        }
        consumed += complete.length;
        carry = chunk.slice(cut + 1);
      }
      state.o = consumed;
      state.s = size;
      state.m = mtime;
    } finally {
      file.close();
    }
  }
  async scan(roots, onProgress) {
    if (this.running) return;
    this.running = true;
    await this.load();
    try {
      const work = roots.flatMap((root) => this.list(root));
      this.total = work.length;
      this.done = 0;
      let sinceReport = 0;
      for (const entry of work) {
        await this.scanFile(entry);
        this.done += 1;
        if (++sinceReport >= 150) {
          sinceReport = 0;
          await this.persist();
          onProgress?.();
          await new Promise((resolve) => setTimeout(resolve, 0));
        }
      }
      await this.persist();
    } catch (err) {
      this.log(`transcript scan failed: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      this.running = false;
      onProgress?.();
    }
  }
  machine(sharedBy) {
    const days = Object.keys(this.rollup.days).sort().slice(-DAYS_SHOWN).map((day) => ({ day, toks: toks(this.rollup.days[day]), messages: this.rollup.dayMessages[day] ?? 0 }));
    const sessionCount = Object.values(this.files).filter((state) => !state.sb).length;
    const projects = Object.entries(this.rollup.projects).map(([path, quad]) => ({ name: projectName2(path), path, toks: toks(quad) })).sort((a, b) => total(b.toks) - total(a.toks)).slice(0, TOP_PROJECTS);
    const models = Object.entries(this.rollup.models).filter(([model]) => !model.startsWith("<")).map(([model, quad]) => ({ model, toks: toks(quad) })).sort((a, b) => total(b.toks) - total(a.toks));
    const totals = { input: 0, cacheWrite: 0, cacheRead: 0, output: 0 };
    for (const quad of Object.values(this.rollup.days)) {
      totals.input += quad[0];
      totals.cacheWrite += quad[1];
      totals.cacheRead += quad[2];
      totals.output += quad[3];
    }
    return {
      days,
      projects,
      models,
      totals,
      totalMessages: this.rollup.messages,
      totalSessions: sessionCount,
      scan: { done: this.done, total: this.total, running: this.running },
      sharedBy
    };
  }
  liveModels(now = Date.now()) {
    const out = /* @__PURE__ */ new Set();
    for (const state of Object.values(this.files)) {
      const lastAt = state.at ?? state.m;
      if (state.sb || !lastAt || now - lastAt > SESSION_HORIZON_MS) continue;
      if (state.md) out.add(state.md);
    }
    return [...out];
  }
  sessions(limitFor, now = Date.now()) {
    const out = [];
    for (const [path, state] of Object.entries(this.files)) {
      const lastAt = state.at ?? state.m;
      if (state.sb || !state.cwd || !lastAt || now - lastAt > SESSION_HORIZON_MS) continue;
      const age = now - state.m;
      const status = age < RUNNING_MS ? "running" : state.pt ? "waiting" : "idle";
      out.push({
        id: state.sid ?? path.slice(path.lastIndexOf("/") + 1).replace(/\.jsonl$/, ""),
        project: projectName2(state.cwd),
        cwd: state.cwd,
        title: state.ti ?? null,
        branch: state.br ?? null,
        model: state.md ?? null,
        contextTokens: state.cx ?? 0,
        contextLimit: limitFor(state.md ?? null),
        lastAt: state.m,
        status,
        pendingTool: state.pt ?? null
      });
    }
    const rank = { waiting: 0, running: 1, idle: 2 };
    out.sort((a, b) => rank[a.status] - rank[b.status] || b.lastAt - a.lastAt);
    return out;
  }
};
function total(value) {
  return value.input + value.cacheWrite + value.cacheRead + value.output;
}

// extension/usage.ts
var USAGE_URL = "https://api.anthropic.com/api/oauth/usage";
var OAUTH_BETA2 = "oauth-2025-04-20";
var UsageError = class extends Error {
  constructor(kind, message, retryAfterMs = 0) {
    super(message);
    this.kind = kind;
    this.retryAfterMs = retryAfterMs;
  }
  kind;
  retryAfterMs;
};
var DEFAULT_BACKOFF_MS = 5 * 60 * 1e3;
function backoff(response) {
  const header = Number(response.headers.get("retry-after"));
  return Number.isFinite(header) && header > 0 ? header * 1e3 : DEFAULT_BACKOFF_MS;
}
function titleize(kind) {
  return kind.split(/[_-]/).filter(Boolean).map((word) => word[0].toUpperCase() + word.slice(1)).join(" ");
}
function limitLabel(limit) {
  const scoped = limit.scope?.model?.display_name ?? limit.scope?.surface ?? null;
  if (scoped) return scoped;
  if (limit.kind === "session") return "Session";
  if (limit.kind === "weekly_all") return "Weekly";
  if (limit.kind === "weekly_scoped") return "Weekly scoped";
  return titleize(limit.kind ?? "limit");
}
function millis(value) {
  if (!value) return null;
  const at = Date.parse(value);
  return Number.isFinite(at) ? at : null;
}
function shape(raw) {
  const limits = (raw.limits ?? []).map((limit) => ({
    kind: limit.kind ?? "unknown",
    group: limit.group ?? limit.kind ?? "other",
    label: limitLabel(limit),
    percent: Math.max(0, Math.round(limit.percent ?? 0)),
    severity: limit.severity ?? "normal",
    resetsAt: millis(limit.resets_at),
    isActive: limit.is_active === true
  }));
  const rawExtra = raw.extra_usage ?? null;
  const extra = rawExtra ? {
    enabled: rawExtra.is_enabled === true,
    utilization: rawExtra.utilization ?? null,
    usedCredits: rawExtra.used_credits ?? null,
    monthlyLimit: rawExtra.monthly_limit ?? null,
    currency: rawExtra.currency ?? "USD",
    disabledReason: rawExtra.disabled_reason ?? null
  } : null;
  const rawSpend = raw.spend ?? null;
  const spend = rawSpend ? {
    enabled: rawSpend.enabled === true,
    percent: Math.max(0, Math.round(rawSpend.percent ?? 0)),
    severity: rawSpend.severity ?? "normal",
    usedMinor: rawSpend.used?.amount_minor ?? 0,
    currency: rawSpend.used?.currency ?? "USD",
    exponent: rawSpend.used?.exponent ?? 2,
    capMinor: rawSpend.cap?.amount_minor ?? null
  } : null;
  return { limits, extra, spend };
}
async function fetchUsage(accessToken, signal) {
  let response;
  try {
    response = await fetch(USAGE_URL, {
      headers: { authorization: `Bearer ${accessToken}`, "anthropic-beta": OAUTH_BETA2 },
      signal
    });
  } catch (err) {
    throw new UsageError("network", err instanceof Error ? err.message : String(err));
  }
  if (response.status === 429) {
    await response.body?.cancel();
    throw new UsageError("rate-limited", "the usage endpoint is rate limiting", backoff(response));
  }
  if (response.status === 401 || response.status === 403) {
    const body = await response.json().catch(() => null);
    throw new UsageError("unauthorized", body?.error?.message ?? `http ${response.status}`);
  }
  if (!response.ok) {
    await response.body?.cancel();
    throw new UsageError("network", `http ${response.status}`);
  }
  return shape(await response.json());
}

// extension/main.ts
var DEFAULT_POLL_SECONDS = 120;
var SCAN_INTERVAL_MS = 15e3;
var LABEL_TTL_MS = 30 * 60 * 1e3;
var KV_READINGS = "usage.readings";
var DEFAULT_HOOK_PORT = 8791;
var DEFAULT_HOOK_SECONDS = 25;
var DEFAULT_HOOK_TOOLS = "Bash|Write|Edit|NotebookEdit";
function parseSpecs(raw) {
  if (!raw?.trim()) return [];
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.map((entry) => entry).filter((entry) => typeof entry.dir === "string" && entry.dir.length > 0).map((entry) => ({ dir: entry.dir, label: entry.label, refresh: entry.refresh === true }));
  } catch {
    return [];
  }
}
function num(config, key, fallback, min) {
  const parsed = Number(config[key]);
  return Number.isFinite(parsed) && parsed >= min ? parsed : fallback;
}
function pollSeconds(config) {
  return num(config, "pollSeconds", DEFAULT_POLL_SECONDS, 15);
}
function hookSettings(config) {
  return {
    enabled: config.hooks === "true",
    port: num(config, "hookPort", DEFAULT_HOOK_PORT, 1024),
    seconds: num(config, "hookSeconds", DEFAULT_HOOK_SECONDS, 5),
    tools: config.hookTools?.trim() || DEFAULT_HOOK_TOOLS
  };
}
function view(slot) {
  const reading = slot.reading;
  return {
    id: slot.spec.dir,
    dir: slot.spec.dir,
    label: slot.spec.label ?? slot.label?.email ?? displayName(slot.spec.dir),
    org: slot.label?.orgName ?? null,
    plan: slot.label?.subscriptionType ?? slot.plan,
    tier: slot.label?.tier ?? slot.tier,
    limits: reading?.limits ?? [],
    extra: reading?.extra ?? null,
    spend: reading?.spend ?? null,
    readingAt: slot.readingAt,
    stale: slot.stale,
    refreshEnabled: slot.spec.refresh === true
  };
}
var Runner = class {
  constructor(ctx) {
    this.ctx = ctx;
    this.scanner = new TranscriptScanner(ctx.kv, (message) => ctx.log.warn(message));
    this.limits = new ModelLimits(ctx.kv, (message) => ctx.log.warn(message));
    this.prompts = new PromptServer(
      () => this.pushPrompts(),
      () => this.ctx.devices.some((device) => device.connected && device.active),
      (message) => this.ctx.log.debug(message)
    );
  }
  ctx;
  slots = /* @__PURE__ */ new Map();
  scanner;
  limits;
  usageTimer;
  scanTimer;
  polling = false;
  sharedBy = [];
  prompts;
  hookInstalledIn = [];
  hookWanted = null;
  discovered = [];
  send(push, device) {
    if (device) device.send(json(push));
    else this.ctx.broadcast(json(push));
  }
  specs() {
    this.rediscover();
    for (const device of this.ctx.devices) {
      const configured = parseSpecs(device.config.accounts);
      if (configured.length > 0) return configured;
    }
    return this.discovered.map((account) => ({ dir: account.dir }));
  }
  rediscover() {
    this.discovered = discover().map((account) => ({ dir: account.dir, name: account.name }));
  }
  settings() {
    return this.ctx.devices[0]?.config ?? {};
  }
  interval() {
    return pollSeconds(this.settings()) * 1e3;
  }
  async start() {
    await this.limits.ready();
    const stored = await this.ctx.kv.get(KV_READINGS) ?? {};
    for (const spec of this.specs()) {
      const held = stored[spec.dir];
      this.slots.set(spec.dir, {
        spec,
        label: null,
        labelAt: 0,
        plan: null,
        tier: null,
        reading: held?.reading ?? null,
        readingAt: held?.at ?? null,
        stale: null,
        retryAfter: 0
      });
    }
    this.pushAccounts();
    this.arm();
    void this.syncHook();
    void this.pollUsage();
    void this.pollTranscripts();
  }
  async syncHook() {
    const wanted = hookSettings(this.settings());
    const same = JSON.stringify(wanted) === JSON.stringify(this.hookWanted);
    if (same && wanted.enabled === this.prompts.listening) return;
    this.hookWanted = wanted;
    const dirs = [...this.slots.keys()];
    try {
      if (!wanted.enabled) {
        await this.prompts.stop();
        this.hookInstalledIn = [];
        const removed = await uninstall(dirs);
        if (removed.touched.length > 0) {
          this.ctx.log.info(`removed the PreToolUse hook from ${removed.touched.join(", ")}`);
        }
      } else {
        await this.prompts.stop();
        this.prompts.start(wanted.port, wanted.seconds);
        if (!this.prompts.listening) {
          this.ctx.log.error(`could not listen on 127.0.0.1:${wanted.port}: ${this.prompts.error}`);
          await uninstall(dirs);
          this.hookInstalledIn = [];
        } else {
          const applied = await install(dirs, wanted.tools, this.prompts.url(wanted.port), wanted.seconds);
          this.hookInstalledIn = applied.touched;
          for (const failure of applied.failed) {
            this.ctx.log.error(`could not write ${failure.path}: ${failure.detail}`);
          }
          this.ctx.log.info(`PreToolUse hook for ${wanted.tools} in ${applied.touched.join(", ") || "nothing new"}`);
        }
      }
    } catch (err) {
      this.ctx.log.error(`hook sync failed: ${err instanceof Error ? err.message : String(err)}`);
    }
    this.pushPrompts();
  }
  hookStatus() {
    return {
      enabled: this.hookWanted?.enabled === true,
      listening: this.prompts.listening,
      holding: this.prompts.holding,
      installedIn: this.hookInstalledIn,
      error: this.prompts.error
    };
  }
  pushPrompts(device) {
    this.send({ t: "prompts", at: Date.now(), prompts: this.prompts.queue(), hook: this.hookStatus() }, device);
  }
  present() {
    this.prompts.markPresent();
  }
  answer(id, decision) {
    this.prompts.answer(id, decision);
  }
  arm() {
    clearInterval(this.usageTimer);
    clearInterval(this.scanTimer);
    this.usageTimer = setInterval(() => void this.pollUsage(), this.interval());
    this.scanTimer = setInterval(() => void this.pollTranscripts(), SCAN_INTERVAL_MS);
  }
  async stop() {
    clearInterval(this.usageTimer);
    clearInterval(this.scanTimer);
    await this.prompts.stop();
  }
  reconfigure() {
    const wanted = this.specs();
    const keep = new Set(wanted.map((spec) => spec.dir));
    for (const dir of [...this.slots.keys()]) if (!keep.has(dir)) this.slots.delete(dir);
    for (const spec of wanted) {
      const existing = this.slots.get(spec.dir);
      if (existing) existing.spec = spec;
      else
        this.slots.set(spec.dir, {
          spec,
          label: null,
          labelAt: 0,
          plan: null,
          tier: null,
          reading: null,
          readingAt: null,
          stale: null,
          retryAfter: 0
        });
    }
    this.arm();
    void this.syncHook();
    void this.pollUsage();
  }
  pushAccounts(device) {
    const accounts = [...this.slots.values()].map(view);
    this.send({ t: "accounts", at: Date.now(), accounts, discovered: this.discovered, polling: this.polling }, device);
  }
  pushMachine(device) {
    this.send({ t: "machine", at: Date.now(), machine: this.scanner.machine(this.sharedBy) }, device);
  }
  pushSessions(device) {
    const sessions = this.scanner.sessions((model) => this.limits.limit(model));
    this.send({ t: "sessions", at: Date.now(), sessions }, device);
  }
  pushAll(device) {
    this.pushAccounts(device);
    this.pushMachine(device);
    this.pushSessions(device);
    this.pushPrompts(device);
  }
  async primeLimits() {
    const models = this.scanner.liveModels();
    if (models.length === 0) return false;
    for (const slot of this.slots.values()) {
      if (slot.stale) continue;
      const credential = await readCredential(slot.spec.dir);
      if (!credential || credential.expiresAt <= Date.now()) continue;
      return await this.limits.prime(models, credential.accessToken);
    }
    return false;
  }
  async pollUsage() {
    if (this.polling) return;
    this.polling = true;
    this.rediscover();
    this.pushAccounts();
    try {
      await Promise.all([...this.slots.values()].map((slot) => this.pollOne(slot)));
      const stored = {};
      for (const slot of this.slots.values()) {
        if (slot.reading && slot.readingAt) stored[slot.spec.dir] = { reading: slot.reading, at: slot.readingAt };
      }
      await this.ctx.kv.set(KV_READINGS, stored).catch(() => {
      });
    } finally {
      this.polling = false;
      this.pushAccounts();
    }
  }
  async pollOne(slot) {
    const now = Date.now();
    if (now < slot.retryAfter) return;
    if (!slot.label || now - slot.labelAt > LABEL_TTL_MS) {
      slot.label = await readLabel(slot.spec.dir);
      slot.labelAt = now;
    }
    let credential = await readCredential(slot.spec.dir);
    if (!credential) {
      slot.stale = { reason: "no-credential", detail: "no token in the store", since: slot.readingAt ?? now };
      return;
    }
    slot.plan = credential.subscriptionType;
    slot.tier = credential.rateLimitTier;
    if (needsRefresh(credential)) {
      if (slot.spec.refresh) {
        const outcome = await refreshCredential(slot.spec.dir, this.ctx.dataDir);
        if (outcome.kind === "refreshed" || outcome.kind === "already-fresh") credential = outcome.credential;
        else if (outcome.kind === "failed") this.ctx.log.warn(`refresh failed for ${slot.spec.dir}: ${outcome.detail}`);
      }
      if (credential.expiresAt <= Date.now()) {
        slot.stale = {
          reason: "expired",
          detail: "run claude in this account to refresh",
          since: slot.readingAt ?? now
        };
        return;
      }
    }
    try {
      slot.reading = await fetchUsage(credential.accessToken);
      slot.readingAt = Date.now();
      slot.stale = null;
    } catch (err) {
      if (err instanceof UsageError && err.kind === "rate-limited") {
        slot.retryAfter = Date.now() + err.retryAfterMs;
        return;
      }
      const reason = err instanceof UsageError && err.kind === "unauthorized" ? "unauthorized" : "network";
      const detail = err instanceof Error ? err.message : String(err);
      slot.stale = { reason, detail, since: slot.readingAt ?? now };
    }
  }
  async pollTranscripts() {
    const accounts = [...this.slots.values()].map((slot) => ({
      dir: slot.spec.dir,
      name: slot.spec.label ?? displayName(slot.spec.dir),
      isDefault: false
    }));
    const roots = projectsRoots(accounts);
    this.sharedBy = [...roots.values()].find((owners) => owners.length > 1) ?? [];
    await this.scanner.scan([...roots.keys()], () => {
      this.pushMachine();
      this.pushSessions();
    });
    this.pushMachine();
    this.pushSessions();
    if (await this.primeLimits()) this.pushSessions();
  }
};
var runner;
defineExtension({
  start(ctx) {
    const active = new Runner(ctx);
    runner = active;
    ctx.on("device", (event) => {
      if (event.type === "disconnected") return;
      if (event.device.active) active.pushAll(event.device);
    });
    ctx.on("message", (device, message) => {
      const pull = asJson(message);
      if (!pull) return;
      if (pull.t === "hello") active.pushAll(device);
      else if (pull.t === "refresh") void active.pollUsage().then(() => void active.pollTranscripts());
      else if (pull.t === "present") active.present();
      else if (pull.t === "answer") active.answer(pull.id, pull.decision);
    });
    ctx.on("config", () => active.reconfigure());
    return active.start();
  },
  stop() {
    return runner?.stop();
  }
});
